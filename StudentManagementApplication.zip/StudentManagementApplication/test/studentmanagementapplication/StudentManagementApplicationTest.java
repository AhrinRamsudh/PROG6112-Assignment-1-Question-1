/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package studentmanagementapplication;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Ahrin Ramsudh
 */
public class StudentManagementApplicationTest {
    
    public StudentManagementApplicationTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

   
@Test
// save student test
    public void testSaveStudent() {
        
        
        StudentManagementApplication app = new StudentManagementApplication();

        // test student used from assignment
        int studentId = 10111;
        String studentName = "J.Bloggs";
        int studentAge = 19;
        String studentEmail = "jbloggs@gmail.com";
        String studentCourse = "disd";

        // printed output
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));

        //  user input 
        ByteArrayInputStream inputStream = new ByteArrayInputStream(
            String.format("%d%n%s%n%d%n%s%n%s%n5%n", studentId, studentName, studentAge, studentEmail, studentCourse).getBytes()
        );
        System.setIn(inputStream);

        // call method
        app.captureNewStudent();

        // set input and output 
        System.setIn(System.in);
        System.setOut(System.out);

        // output
        String capturedOutput = outputStream.toString();

        // success message
        assertTrue(capturedOutput.contains("Student added successfully."));

        // array
        assertEquals(1, app.studentList.size());
        Student savedStudent = app.studentList.get(0);

        
        assertEquals(studentId, savedStudent.getStudentId());
        assertEquals(studentName, savedStudent.getStudentName());
        assertEquals(studentAge, savedStudent.getStudentAge());
        assertEquals(studentEmail, savedStudent.getStudentEmail());
        assertEquals(studentCourse, savedStudent.getStudentCourse());
    }
    
    
    
    
     @Test
     // search for student test 
    public void testSearchStudent() {
        
        StudentManagementApplication app = new StudentManagementApplication();

        // test student used from assignment
        int studentId = 10111; 
        String studentName = "J.Bloggs";
        int studentAge = 19;
        String studentEmail = "jbloggs@gmail.com";
        String studentCourse = "disd";

        
        Student testStudent = new Student(studentId, studentName, studentAge, studentEmail, studentCourse);
        app.studentList.add(testStudent);

        app.searchForStudent();

      
        assertEquals(studentId, app.studentList.get(0).getStudentId());
        assertEquals(studentName, app.studentList.get(0).getStudentName());
        assertEquals(studentAge, app.studentList.get(0).getStudentAge());
        assertEquals(studentEmail, app.studentList.get(0).getStudentEmail());
        assertEquals(studentCourse, app.studentList.get(0).getStudentCourse());
    }
    
    
    @Test
    // search for student test (when student is not found) 
    public void testSearchStudent_StudentNotFound() {
        
        StudentManagementApplication app = new StudentManagementApplication();

        // test student used from assignment 
        int studentId = 10111; 
        String studentName = "J.Bloggs";
        int studentAge = 19;
        String studentEmail = "jbloggs@gmail.com";
        String studentCourse = "disd";

        
        Student testStudent = new Student(studentId, studentName, studentAge, studentEmail, studentCourse);
        app.studentList.add(testStudent);

        // output
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));

        // incorrect id  
        int incorrectStudentId = 10001;
        System.setIn(new ByteArrayInputStream(String.valueOf(incorrectStudentId).getBytes()));

        // call method
        app.searchForStudent();

        // set input and output 
        System.setIn(System.in);
        System.setOut(System.out);

        // output
        String capturedOutput = outputStream.toString();

        // message (when the student was not found)
         assertTrue(capturedOutput.contains("Student with student ID " + incorrectStudentId + " not found."));
    }
    
    @Test
    // delete student test 
    public void testDeleteStudent() {
        
        StudentManagementApplication app = new StudentManagementApplication();

        // Create a test student
        int studentId = 10111; 
        String studentName = "J.Bloggs";
        int studentAge = 19;
        String studentEmail = "jbloggs@email.com";
        String studentCourse = "disd";

        
        Student testStudent = new Student(studentId, studentName, studentAge, studentEmail, studentCourse);
        app.studentList.add(testStudent);

        // call method
        app.deleteStudent();

        
        assertEquals(0, app.studentList.size());
    }
    
    
    @Test
        // delete student test (when student is not found) 
    public void testDeleteStudent_StudentNotFound() {
        
        StudentManagementApplication app = new StudentManagementApplication();

        // incorrect id
        int incorrectStudentId = 10001;
        ByteArrayInputStream inputStream = new ByteArrayInputStream(
            String.format("%d%n5%n", incorrectStudentId).getBytes()
        );
        
        System.setIn(inputStream);

        // call method
        app.deleteStudent();

        // set input
        System.setIn(System.in);

        
        assertEquals(0, app.studentList.size());
        
    }
    
    @Test
    // student age test(valid)
    public void testStudentAge_StudentAgeValid() {
        
        StudentManagementApplication app = new StudentManagementApplication();

        // valid age declaration 
        int validStudentAge = 16;

        
        assertEquals(1, app.studentList.size());

        
        assertEquals(validStudentAge, app.studentList.get(0).getStudentAge());
    }
    
    @Test
    // student age test(invalid)
    public void testStudentAge_StudentAgeInvalid() {
        
        StudentManagementApplication app = new StudentManagementApplication();

       // invalid age declaration 
        int invalidStudentAge = 15;


        assertEquals(0, app.studentList.size());
    }
    
    @Test
    public void testStudentAge_StudentAgeInvalidCharacter() {
        // Create an instance of StudentManagementApplication
        StudentManagementApplication app = new StudentManagementApplication();

        // all non numeric characters 
        String invalidStudentAgeInput = ": ! @ # & ( ) – [ { } ] : ; ', ? / *.!@#$%^&+_AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz";

   
        assertEquals(0, app.studentList.size());
    }
}


    










   
