/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studentmanagementapplication;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Ahrin Ramsudh
 */

public class StudentManagementApplication {
    
    //ArrayList
    static ArrayList<Student> studentList = new ArrayList<>();
    //Scanner Object
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        
        //choices
        while (true) {
            displayMenu();
            
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    captureNewStudent();
                    break;
                case 2:
                    searchForStudent();
                    break;
                case 3:
                    deleteStudent();
                    break;
                case 4:
                    printStudentReport();
                    break;
                case 5:
                    exitApplication();
                    break;
                default:
                    
                    System.out.println("Invalid choice. Please select a valid option.");
                    System.out.println("");
            }
        }
    }

    private static void displayMenu() {
        //main menu
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("******************************");
        System.out.println("");
        // options
        System.out.println("1) Capture a new student");
        System.out.println("2) Search for a student");
        System.out.println("3) Delete a student");
        System.out.println("4) Print student report");
        System.out.println("5) Exit application");
        System.out.println("");
        System.out.print("Enter your choice: ");//enter no. 1 - 5 
    }

    static void captureNewStudent() {
        // capture a new student - option 1 
        System.out.println("");
      System.out.println("CAPTURE A NEW STUDENT");
        System.out.println("*********************");
        
        //enter detials of student
        System.out.println("");
        System.out.print("Enter the student id: ");
        int studentId = scanner.nextInt();
        scanner.nextLine(); 
        System.out.print("Enter the student name: ");
        String studentName = scanner.nextLine();
        
        // age check
        int studentAge;
        
        do {
            System.out.print("Enter the student age: ");
            studentAge = scanner.nextInt();
            if (studentAge < 16) {
                System.out.println("You have entered a invalid age!");
                System.out.println("");
            }
        } while (studentAge < 16);
        scanner.nextLine();
        System.out.print("Enter student email: ");
        String studentEmail = scanner.nextLine();
        System.out.print("Enter student's course: ");
        String studentCourse = scanner.nextLine();
        System.out.println("");

        // student list 
        Student student = new Student(studentId, studentName, studentAge, studentEmail, studentCourse);
        studentList.add(student);

        System.out.println("Student added successfully."); // if all detail are enterd properly 
        System.out.println("");
    }

    static void searchForStudent() {
        //student search - option 2
        System.out.println("");
        System.out.println("SEARCH FOR A STUDENT");  
    System.out.println("********************");
    System.out.println("");
    System.out.print("Enter the student ID to search: "); // enter student id 
    int studentIdToSearch = scanner.nextInt();
    scanner.nextLine(); 

    boolean found = false;
// output after student id has been searched
    for (Student student : studentList) {
        if (student.getStudentId() == studentIdToSearch) {
            System.out.println("----------------------------------------");
            System.out.println("STUDENT ID: " + student.getStudentId());
            System.out.println("STUDENT NAME: " + student.getStudentName());
            System.out.println("STUDENT AGE: " + student.getStudentAge());
            System.out.println("STUDENT EMAIL: " + student.getStudentEmail());
            System.out.println("STUDENT COURSE: " + student.getStudentCourse());
            System.out.println("----------------------------------------");
            System.out.println("");
            found = true;
            break;
        }
    }
// if id is not found in system 
    if (!found) {
        System.out.println("");
        System.out.println("Student with student ID " + studentIdToSearch + " not found.");
        System.out.println("");
    }
    }

    static void deleteStudent() {
        // student deletion - option 3
        System.out.println("");
        System.out.println("DELETE A STUDENT");
        System.out.println("****************");
        System.out.println("");
        
        System.out.print("Enter the student id to delete: "); // the student id  
        int studentIdToDelete = scanner.nextInt();
        scanner.nextLine(); 

        for (Student student : studentList) {
            if (student.getStudentId() == studentIdToDelete) {
                System.out.println("Are you sure you want to delete student " + studentIdToDelete + " from the system? Yes (y) to delete: "); // option to delete or not 
                String confirmation = scanner.nextLine().toLowerCase();
                if (confirmation.equals("y")) {
                    studentList.remove(student);
                       System.out.println("----------------------------------------");
                    System.out.println("Student with student Id " + studentIdToDelete + " was deleted."); //deletion message 
                       System.out.println("----------------------------------------");
                    System.out.println("");
                    return;
                } else {
                    System.out.println("");
                    System.out.println("Deletion canceled."); // if "y" is not typed 
                    System.out.println("");
                    return;
                }
            }
        }

        System.out.println("Student with student id " + studentIdToDelete + " not found."); //if student with id is not found 
        System.out.println("");
    
    }

    private static void printStudentReport() {
        
        //student reports - option 4 
        System.out.println("");
       System.out.println("STUDENT REPORT");
    System.out.println("**************");
    System.out.println("");

    int studentCount = studentList.size(); // size
    
    if (studentCount == 0) {
        System.out.println("No students found in the system."); 
        System.out.println("");
        return;
    }

    for (int i = 0; i < studentCount; i++) {
        Student student = studentList.get(i);

        //layout and output if students are founf in system 
        System.out.println("STUDENT " + (i + 1));
        System.out.println("----------------------------------------");
        System.out.println("STUDENT ID: " + student.getStudentId());
        System.out.println("STUDENT NAME: " + student.getStudentName());
        System.out.println("STUDENT AGE: " + student.getStudentAge());
        System.out.println("STUDENT EMAIL: " + student.getStudentEmail());
        System.out.println("STUDENT COURSE: " + student.getStudentCourse());
        System.out.println("----------------------------------------");
        System.out.println("");
    }
    }

    private static void exitApplication() {
        
        //exit apllication - option 5 
        System.out.println("");
        System.out.println("Exiting the application. Goodbye"); // goodbye message
        System.exit(0);
    }

    
}
