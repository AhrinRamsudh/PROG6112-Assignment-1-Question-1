/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package studentmanagementapplication;

import java.util.ArrayList;

/**
 *
 * @author Ahrin Ramsudh
 */
public class Student {
    
    // Methods 
    private int studentId;
    private String studentName;
    private int studentAge;
    private String studentEmail;
    private String studentCourse;

    // getters 
    public int getStudentId() {
        return studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public int getStudentAge() {
        return studentAge;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public String getStudentCourse() {
        return studentCourse;
    }

    public Student(int studentId, String studentName, int studentAge, String studentEmail, String studentCourse) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.studentAge = studentAge;
        this.studentEmail = studentEmail;
        this.studentCourse = studentCourse;
    }

    public static void saveStudent(ArrayList<Student> studentList, Student student) {
        studentList.add(student);
    }

    public static Student searchStudent(ArrayList<Student> studentList, int searchId) {
        for (Student student : studentList) {
            if (student.getStudentId() == searchId) {
                return student; // Student found
            }
        }
        return null; // Student not found
    }

    public static boolean deleteStudent(ArrayList<Student> studentList, int deleteId) {
        for (Student student : studentList) {
            if (student.getStudentId() == deleteId) {
                studentList.remove(student);
                return true; // Student deleted
            }
        }
        return false; // Student not found
    }

    public static void studentReport(ArrayList<Student> studentList) {
        System.out.println("STUDENT REPORT");
        System.out.println("*******************************");
        int studentCount = 1;
        for (Student student : studentList) {
            System.out.println("STUDENT " + studentCount);
            System.out.println("----------------------------------------");
            System.out.println("STUDENT ID: " + student.getStudentId());
            System.out.println("STUDENT NAME: " + student.getStudentName());
            System.out.println("STUDENT AGE: " + student.getStudentAge());
            System.out.println("STUDENT EMAIL: " + student.getStudentEmail());
            System.out.println("STUDENT COURSE: " + student.getStudentCourse());
            System.out.println("----------------------------------------");
            studentCount++;
        }
}
}